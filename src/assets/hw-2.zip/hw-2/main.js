"use strict";
// 1---1-----
// const users = [
//     {
//         id: 1,
//         name: "John Doe",
//         email: "john.doe@example.com",
//         address: "123 Main St, Springfield, IL",
//     },
//     {
//         id: 2,
//         name: "Jane Smith",
//         email: "jane.smith@example.com",
//         address: "456 Oak Rd, Metropolis, NY",
//     },
//     {
//         id: 3,
//         name: "Alice Johnson",
//         email: "alice.johnson@example.com",
//         address: "789 Pine Ave, Rivertown, TX",
//     },
//     {
//         id: 4,
//         name: "Bob Brown",
//         email: "bob.brown@example.com",
//         address: "101 Maple Blvd, Lakeside, FL",
//     },
//     {
//         id: 5,
//         name: "Charlie Green",
//         email: "charlie.green@example.com",
//         address: "567 Elm St, Greenfield, CA",
//     },
//     {
//         id: 6,
//         name: "Diana Adams",
//         email: "diana.adams@example.com",
//         address: "890 Birch Rd, Woodville, CO",
//     },
//     {
//         id: 7,
//         name: "Ethan Clark",
//         email: "ethan.clark@example.com",
//         address: "234 Cedar Ln, Hilltown, GA",
//     },
//     {
//         id: 8,
//         name: "Fiona White",
//         email: "fiona.white@example.com",
//         address: "901 Aspen Blvd, Valleyview, AZ",
//     },
//     {
//         id: 9,
//         name: "George Black",
//         email: "george.black@example.com",
//         address: "456 Willow Way, Brooksville, MI",
//     },
//     {
//         id: 10,
//         name: "Hannah Gray",
//         email: "hannah.gray@example.com",
//         address: "789 Spruce Ct, Clearview, WA",
//     },
// ];
// const findUser = (arr: Array<UserType>, id: number) => {
//     return arr.find((user: UserType) => {
//         if (user.id === id) {
//             return user.address;
//         }
//     });
// };
// console.log(findUser(users, 6));
//--1--8-
// const users = [
//     {
//         id: 1,
//         name: "John Doe",
//         email: "john.doe@example.com",
//         address: "123 Main St, Springfield, IL",
//     },
//     {
//         id: 2,
//         name: "Jane Smith",
//         email: "jane.smith@example.com",
//         address: "456 Oak Rd, Metropolis, NY",
//     },
//     {
//         id: 3,
//         name: "Alice Johnson",
//         email: "alice.johnson@example.com",
//         address: "789 Pine Ave, Rivertown, TX",
//     },
//     {
//         id: 4,
//         name: "Bob Brown",
//         email: "bob.brown@example.com",
//         address: "101 Maple Blvd, Lakeside, FL",
//     },
//     {
//         id: 5,
//         name: "Charlie Green",
//         email: "charlie.green@example.com",
//         address: "567 Elm St, Greenfield, CA",
//     },
//     {
//         id: 6,
//         name: "Diana Adams",
//         email: "diana.adams@example.com",
//         address: "890 Birch Rd, Woodville, CO",
//     },
//     {
//         id: 7,
//         name: "Ethan Clark",
//         email: "ethan.clark@example.com",
//         address: "234 Cedar Ln, Hilltown, GA",
//     },
//     {
//         id: 8,
//         name: "Fiona White",
//         email: "fiona.white@example.com",
//         address: "901 Aspen Blvd, Valleyview, AZ",
//     },
//     {
//         id: 9,
//         name: "George Black",
//         email: "george.black@example.com",
//         address: "456 Willow Way, Brooksville, MI",
//     },
//     {
//         id: 10,
//         name: "Hannah Gray",
//         email: "hannah.gray@example.com",
//         address: "789 Spruce Ct, Clearview, WA",
//     },
// ];
// const names: string[] = [];
// const findNames = (arr: Array<UserType>) => {
//     return arr.map((user: UserType) => {
//         names.push(user.name);
//     });
// };
// findNames(users);
// console.log(names);
//--1--9-
// const arr1: (number | string)[] = [1, 2, 3, 4, 5, 6, 7, 8, 9];
// const arr2: (number | string)[] = [12, 13, 14, 15, 16, 17, 18, 19];
// const pushToArray = (arr1: (number | string)[], arr2: (number | string)[]) => {
//     const findMax = (arr: (number | string)[]) =>
//         Math.max(
//             ...(arr.filter(item => typeof item === "number") as number[])
//         ).toString();
//     arr1.push(findMax(arr2));
//     arr2.push(findMax(arr1));
// };
// pushToArray(arr1, arr2);
// console.log(arr1);
// console.log(arr2);
// ---1---10
// const arr1: number[] = [1, -2, 3, -4, 5, -6, 7, -8, 9];
// const active: Array<number> = [];
// const passive: Array<number> = [];
// const filterNumber = (arr: Array<number>) => {
//     return arr.forEach((num: number) =>
//         num < 0 ? passive.push(num) : active.push(num)
//     );
// };
// filterNumber(arr1);
// console.log(active, passive);
//---2---1
// const num: number = 456;
// const reverseNumber = (num: number): number => {
//     if (num < 10 && num > -10) {
//         return num;
//     }
//     const reversed =
//         parseInt(num.toString().split("").reverse().join("")) * Math.sign(num);
//     return reversed;
// };
// console.log(reverseNumber(num));
//---2---3
// type User = {
//     name: string;
//     age: number;
// };
// const compareAges = (user1: User, user2: User): void => {
//     if (user1.age > user2.age) {
//         console.log(user1.name);
//     } else {
//         console.log(user2.name);
//     }
// };
// const user1 = { name: "Anvar", age: 25 };
// const user2 = { name: "Laylo", age: 30 };
// compareAges(user1, user2);
///2---4--
// const printNumbers = (num: number): void => {
//     if (num <= 0) return;
//     console.log(num);
//     printNumbers(num - 1);
// };
// printNumbers(5);
///--2----5
// const mergeObjects = (...objects: object[]): object => {
//     return Object.assign({}, ...objects);
// };
// let user = { name: "Laylo" };
// let age = { age: 13 };
// let userJob = { job: "student" };
// const userA = mergeObjects(user, age, userJob);
// console.log(userA);
///--2----5
// let salaries = {
//     aXodim: 150,
//     bXodim: 250,
//     cXodim: 350,
// };
// const totalSalaries = (salaries: object): number => {
//     return Object.values(salaries).reduce((acc, salary) => acc + salary, 0);
// };
// totalSalaries(salaries);
// console.log(totalSalaries(salaries));
